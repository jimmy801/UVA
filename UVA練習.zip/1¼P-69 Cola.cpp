﻿// 1星-69 Cola

// 輸入買幾瓶可樂
// 每3個空瓶可以換一瓶可樂
// 可以和朋友借一個空瓶
// 求最多可以喝幾瓶

#include <iostream>

using namespace std;

int main()
{
	int num;
	while (cin >> num)cout << num + num / 2 << endl;
}